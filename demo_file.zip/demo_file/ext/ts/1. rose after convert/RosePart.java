/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.ts.rose;

import ext.ts.rose.RoseType;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.ClassNotFoundException;
import java.lang.Object;
import java.lang.String;
import java.sql.SQLException;
import wt.fc.ObjectReference;
import wt.part.QuantityUnit;
import wt.part.WTPart;
import wt.pds.PersistentRetrieveIfc;
import wt.pds.PersistentStoreIfc;
import wt.pom.DatastoreException;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.Mastered;
import com.ptc.windchill.annotations.metadata.*;

/**
 *
 * <p>
 * Use the <code>newRosePart</code> static factory method(s), not the <code>RosePart</code>
 * constructor, to construct instances of this class.  Instances must be
 * constructed using the static factory(s), in order to ensure proper initialization
 * of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/

@GenAsPersistable(superClass=WTPart.class, 
   serializable=Serialization.EXTERNALIZABLE_BASIC,
   properties={
   @GeneratedProperty(name="att2", type=String.class),
   @GeneratedProperty(name="roseType", type=RoseType.class, initialValue="RoseType.getRoseTypeDefault()",
      accessors=@PropertyAccessors(setExceptions={}),
      constraints=@PropertyConstraints(required=true))
   },
   foreignKeys={
   @GeneratedForeignKey( /* first defined by: Iterated */
      foreignKeyRole=@ForeignKeyRole(name="master", type=ext.ts.rose.RosePartMaster.class, cascade=false,
         constraints=@PropertyConstraints(required=true)),
      myRole=@MyRole(name="iteration", cascade=false))
   },
   derivedProperties={
   @DerivedProperty(name="masterAtt1", derivedFrom="master>masterAtt1")
   })
public class RosePart extends _RosePart {


   static final long serialVersionUID = 1;




   /**
    * Gets the value of the attribute: MASTER_ATT1.
    *
    * @return    String
    **/
   public String getMasterAtt1() {

      try { return ((RosePartMaster) getMaster()).getMasterAtt1(); }
      catch (NullPointerException npe) { return null; }
   }

   /**
    * Sets the value of the attribute: MASTER_ATT1.
    *
    * @param     a_MasterAtt1
    * @exception wt.util.WTPropertyVetoException
    **/
   public void setMasterAtt1( String a_MasterAtt1 )
            throws WTPropertyVetoException {

      ((RosePartMaster) getMaster()).setMasterAtt1( a_MasterAtt1 );
   }

   /**
    * @param     name
    * @param     number
    * @return    RosePart
    * @exception wt.util.WTException
    **/
   public static RosePart newRosePart( String name, String number )
            throws WTException {

      RosePart instance = new RosePart();
      instance.initialize( name, number );
      return instance;
   }

   /**
    * Supports initialization, following construction of an instance.  Invoked
    * by "new" factory having the same signature.
    *
    * @param     name
    * @param     number
    * @exception wt.util.WTException
    **/
   protected void initialize( String name, String number )
            throws WTException {
	  
	  super.initialize(name, number);

   }

   /**
    * @return    RosePart
    * @exception wt.util.WTException
    **/
   public static RosePart newRosePart()
            throws WTException {

      RosePart instance = new RosePart();
      instance.initialize();
      return instance;
   }

   /**
    * @param     number
    * @param     name
    * @param     defaultUnit
    * @return    RosePart
    * @exception wt.util.WTException
    **/
   public static RosePart newRosePart( String number, String name, QuantityUnit defaultUnit )
            throws WTException {

      RosePart instance = new RosePart();
      instance.initialize( number, name, defaultUnit );
      return instance;
   }

   /**
    * Supports initialization, following construction of an instance.  Invoked
    * by "new" factory having the same signature.
    *
    * @param     number
    * @param     name
    * @param     defaultUnit
    * @exception wt.util.WTException
    **/
   protected void initialize( String number, String name, QuantityUnit defaultUnit )
            throws WTException {
		super.initialize( number, name, defaultUnit );
   }

}
