/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.ts.rose;

import ext.ts.rose.RosePart;
import ext.ts.rose.RoseType;
import java.lang.String;
import wt.method.RemoteInterface;
import wt.util.WTException;


/**
 *
 * @version   1.0
 **/

@RemoteInterface
public interface RosePartService {




   /**
    * @param     name
    * @param     type
    * @return    RosePart
    * @exception wt.util.WTException
    **/
   public RosePart createRosePartInSite( String name, RoseType type )
            throws WTException;

}
