/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.ts.rose;

import java.io.Serializable;
import java.lang.IllegalAccessException;
import java.lang.String;
import java.lang.Throwable;
import java.util.Hashtable;
import java.util.Locale;
import wt.fc.EnumeratedType;
import wt.util.WTInvalidParameterException;
import com.ptc.windchill.annotations.metadata.*;

/**
 *
 * @version   1.0
 **/

@GenAsEnumeratedType
public final class RoseType extends _RoseType {






   /**
    **/
   public static final RoseType RT1 = toRoseType("rt1");

   /**
    * Used by sub-classes that need a default constructor.
    *
    **/
   protected RoseType() {

   }

}
