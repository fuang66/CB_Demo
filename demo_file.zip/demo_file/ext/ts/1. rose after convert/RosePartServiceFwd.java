/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.ts.rose;

import ext.ts.rose.RosePart;
import ext.ts.rose.RosePartService;
import ext.ts.rose.RoseType;
import java.lang.String;
import wt.method.RemoteAccess;
import wt.services.ServiceFactory;
import wt.util.WTException;

@Deprecated
public class RosePartServiceFwd implements RosePartService, RemoteAccess {


   public RosePart createRosePartInSite( String name, RoseType type )
            throws WTException {

      // TODO: remove all usages of this Fwd class, then delete it (see ServiceFactory info)
      // forward to remote service implementation
      return ServiceFactory.getService(RosePartService.class).createRosePartInSite( name, type );
   }
}
