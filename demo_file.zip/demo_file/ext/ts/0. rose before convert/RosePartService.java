// Generated RosePartService%4D52641D0329: Wed 02/09/11 15:42:41
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.ts.rose;

import ext.ts.rose.RosePart;
import ext.ts.rose.RoseType;
import java.lang.String;
import wt.method.RemoteInterface;
import wt.util.WTException;

//##begin user.imports preserve=yes
//##end user.imports

//##begin RosePartService%4D52641D0329.doc preserve=no
/**
 *
 * @version   1.0
 **/
//##end RosePartService%4D52641D0329.doc

@RemoteInterface
public interface RosePartService {


   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin createRosePartInSite%4D5266A30319.doc preserve=no
   /**
    * @param     name
    * @param     type
    * @return    RosePart
    * @exception wt.util.WTException
    **/
   //##end createRosePartInSite%4D5266A30319.doc

   public RosePart createRosePartInSite( String name, RoseType type )
            throws WTException;

   //##begin user.operations preserve=yes
   //##end user.operations
}
