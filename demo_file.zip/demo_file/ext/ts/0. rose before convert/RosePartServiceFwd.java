// Generated RosePartServiceFwd%4D52641D0329: Wed 02/09/11 15:42:41
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.ts.rose;

import ext.ts.rose.RosePart;
import ext.ts.rose.RosePartService;
import ext.ts.rose.RoseType;
import java.io.Serializable;
import java.lang.String;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.services.Manager;
import wt.services.ManagerServiceFactory;
import wt.util.WTException;

/**
 *
 * <BR><BR><B>Supported API: </B>false
 * <BR><BR><B>Extendable: </B>false
 *
 * @version   1.0
 **/

public class RosePartServiceFwd implements RemoteAccess, RosePartService, Serializable {


   // --- Attribute Section ---


   static final boolean SERVER = RemoteMethodServer.ServerFlag;
   private static final String FC_RESOURCE = "wt.fc.fcResource";
   private static final String CLASSNAME = RosePartServiceFwd.class.getName();


   // --- Operation Section ---

   /**
    * @return    Manager
    * @exception wt.util.WTException
    **/
   private static Manager getManager()
            throws WTException {

      Manager manager = ManagerServiceFactory.getDefault().getManager( ext.ts.rose.RosePartService.class );
      
      if ( manager == null ) {
         Object[] param = { "ext.ts.rose.RosePartService" };
         throw new WTException( FC_RESOURCE, wt.fc.fcResource.UNREGISTERED_SERVICE, param );
      }
      return manager;
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     name
    * @param     type
    * @return    RosePart
    * @exception wt.util.WTException
    **/
   public RosePart createRosePartInSite( String name, RoseType type )
            throws WTException {

      if (SERVER)
         return ((RosePartService)getManager()).createRosePartInSite( name, type );
      else {
         try {
            Class[]	argTypes	= { String.class, RoseType.class };
            Object[]	args		= { name, type };
            return (RosePart)RemoteMethodServer.getDefault().invoke(
               "createRosePartInSite", null, this, argTypes, args );
         }
         catch (InvocationTargetException e) {
            Throwable targetE = e.getTargetException();
            if ( targetE instanceof WTException )
               throw (WTException)targetE;
            Object[] param = { "createRosePartInSite" };
            throw new WTException( targetE, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
         catch (RemoteException rme) {
            Object[] param = { "createRosePartInSite" };
            throw new WTException( rme, FC_RESOURCE, wt.fc.fcResource.OPERATION_FAILURE, param );
         }
      }
   }
}
