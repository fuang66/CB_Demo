// Generated RosePart%4D525FB60069: Wed 02/09/11 15:28:27
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.ts.rose;

import ext.ts.rose.RoseType;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.ClassNotFoundException;
import java.lang.Object;
import java.lang.String;
import java.sql.SQLException;
import wt.fc.ObjectReference;
import wt.part.QuantityUnit;
import wt.part.WTPart;
import wt.pds.PersistentRetrieveIfc;
import wt.pds.PersistentStoreIfc;
import wt.pom.DatastoreException;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.Mastered;

//##begin user.imports preserve=yes
//##end user.imports

//##begin RosePart%4D525FB60069.doc preserve=no
/**
 *
 * <p>
 * Use the <code>newRosePart</code> static factory method(s), not the <code>RosePart</code>
 * constructor, to construct instances of this class.  Instances must be
 * constructed using the static factory(s), in order to ensure proper initialization
 * of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end RosePart%4D525FB60069.doc

public class RosePart extends WTPart implements Externalizable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.ts.rose.roseResource";
   private static final String CLASSNAME = RosePart.class.getName();

   //##begin ATT2%ATT2.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end ATT2%ATT2.doc
   public static final String ATT2 = "att2";

   private static int ATT2_UPPER_LIMIT = -1;
   private String att2;

   //##begin MASTER_ATT1%MASTER_ATT1.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end MASTER_ATT1%MASTER_ATT1.doc
   public static final String MASTER_ATT1 = "master>masterAtt1";


   //##begin ROSE_TYPE%ROSE_TYPE.doc preserve=no
   /**
    * Label for the attribute.
    **/
   //##end ROSE_TYPE%ROSE_TYPE.doc
   public static final String ROSE_TYPE = "roseType";

   private static int ROSE_TYPE_UPPER_LIMIT = -1;
   private RoseType roseType = RoseType.getRoseTypeDefault();
   static final long serialVersionUID = 1;
   public static final long EXTERNALIZATION_VERSION_UID = 2675224039183947382L;

   // WARNING: Fields placed in this section will not be generated into externalization methods.
   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Writes the non-transient fields of this class to an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.io.IOException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( ObjectOutput output )
            throws IOException {
      //##begin writeExternal%writeExternal.body preserve=no

      output.writeLong( EXTERNALIZATION_VERSION_UID );

      super.writeExternal( output );

      output.writeObject( att2 );
      output.writeObject( (roseType == null ? null : roseType.getStringValue()) );
      //##end writeExternal%writeExternal.body
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Reads the non-transient fields of this class from an external source.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.io.IOException
    * @exception java.lang.ClassNotFoundException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( ObjectInput input )
            throws IOException, ClassNotFoundException {
      //##begin readExternal%readExternal.body preserve=no

      long readSerialVersionUID = input.readLong();                // consume UID

      if ( readSerialVersionUID == EXTERNALIZATION_VERSION_UID ) {  // if current version UID
         super.readExternal( input );                               // handle super class

         att2 = (String)input.readObject();
         String roseType_string_value = (String)input.readObject();
         try { roseType = (RoseType)wt.fc.EnumeratedTypeUtil.toEnumeratedType( roseType_string_value ); }
         catch( wt.util.WTInvalidParameterException e ) { // old format
            roseType = RoseType.toRoseType( roseType_string_value );
         }
      }
      else
         throw new java.io.InvalidClassException( CLASSNAME, "Local class not compatible:"
                           + " stream classdesc externalizationVersionUID=" + readSerialVersionUID 
                           + " local class externalizationVersionUID=" + EXTERNALIZATION_VERSION_UID );
      //##end readExternal%readExternal.body
   }

   //##begin writeExternal%writeExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to obtain the values of the persistent
    * attributes of this class, so they can be written to a persistent store.
    * <p>(Not intended for general use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     output
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end writeExternal%writeExternal.doc

   public void writeExternal( PersistentStoreIfc output )
            throws SQLException, DatastoreException {
      super.writeExternal( output );

      output.setString( "att2", att2 );
      output.setString( "roseType", roseType == null ? null : roseType.toString() );
   }

   //##begin readExternal%readExternal.doc preserve=no
   /**
    * Used by Persistent Data Service to populate the persistent attributes
    * of this class from a persistent store. <p>(Not intended for general
    * use.)
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     input
    * @exception java.sql.SQLException
    * @exception wt.pom.DatastoreException
    **/
   //##end readExternal%readExternal.doc

   public void readExternal( PersistentRetrieveIfc input )
            throws SQLException, DatastoreException {
      super.readExternal( input );

      att2 = input.getString( "att2" );
      String roseType_string_value = input.getString( "roseType" );
      if ( roseType_string_value != null ) {
         roseType = (RoseType)wt.introspection.ClassInfo.getConstrainedEnum( getClass(), "roseType", roseType_string_value );
         if ( roseType == null )  // hard-coded type
            roseType = RoseType.toRoseType( roseType_string_value );
      }
   }

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin getAtt2%4D526015001Fg.doc preserve=no
   /**
    * Gets the value of the attribute: ATT2.
    *
    * @return    String
    **/
   //##end getAtt2%4D526015001Fg.doc

   public String getAtt2() {
      //##begin getAtt2%4D526015001Fg.body preserve=no

      return att2;
      //##end getAtt2%4D526015001Fg.body
   }

   //##begin setAtt2%4D526015001Fs.doc preserve=no
   /**
    * Sets the value of the attribute: ATT2.
    *
    * @param     a_Att2
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setAtt2%4D526015001Fs.doc

   public void setAtt2( String a_Att2 )
            throws WTPropertyVetoException {
      //##begin setAtt2%4D526015001Fs.body preserve=no

      att2Validate( a_Att2 );   // throws exception if not valid
      att2 = a_Att2;
      //##end setAtt2%4D526015001Fs.body
   }

   //##begin att2Validate%4D526015001F.doc preserve=no
   /**
    * @param     a_Att2
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end att2Validate%4D526015001F.doc

   private void att2Validate( String a_Att2 )
            throws WTPropertyVetoException {
      if ( ATT2_UPPER_LIMIT < 1 ) {
         try { ATT2_UPPER_LIMIT = ((Integer)wt.introspection.WTIntrospector.getClassInfo( CLASSNAME ).getPropertyDescriptor( "att2" ).getValue( wt.introspection.WTIntrospector.UPPER_LIMIT )).intValue(); }
         catch (wt.introspection.WTIntrospectionException e) { ATT2_UPPER_LIMIT = 200; } // resort to modeled value
      }
      if ( a_Att2 != null && !wt.fc.PersistenceHelper.checkStoredLength( a_Att2, ATT2_UPPER_LIMIT , true ) ) {   // upper limit check
         Object[] args = { new wt.introspection.PropertyDisplayName( CLASSNAME, "att2" ), String.valueOf( Math.min ( ATT2_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) };
         throw new WTPropertyVetoException( "wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT, args,
               new java.beans.PropertyChangeEvent( this, "att2", att2, a_Att2 ) );
      }
   }

   //##begin getMasterAtt1%4D526105032Cg.doc preserve=no
   /**
    * Gets the value of the attribute: MASTER_ATT1.
    *
    * @return    String
    **/
   //##end getMasterAtt1%4D526105032Cg.doc

   public String getMasterAtt1() {
      //##begin getMasterAtt1%4D526105032Cg.body preserve=yes

      try { return ((RosePartMaster) getMaster()).getMasterAtt1(); }
      catch (NullPointerException npe) { return null; }
      //##end getMasterAtt1%4D526105032Cg.body
   }

   //##begin setMasterAtt1%4D526105032Cs.doc preserve=no
   /**
    * Sets the value of the attribute: MASTER_ATT1.
    *
    * @param     a_MasterAtt1
    * @exception wt.util.WTPropertyVetoException
    **/
   //##end setMasterAtt1%4D526105032Cs.doc

   public void setMasterAtt1( String a_MasterAtt1 )
            throws WTPropertyVetoException {
      //##begin setMasterAtt1%4D526105032Cs.body preserve=yes

      ((RosePartMaster) getMaster()).setMasterAtt1( a_MasterAtt1 );
      //##end setMasterAtt1%4D526105032Cs.body
   }

   //##begin setMaster%4D5260780193p.doc preserve=no
   /**
    * Sets the object for the association that plays role: MASTER.
    *
    * @param     a_Master
    * @exception wt.util.WTPropertyVetoException
    * @exception wt.util.WTException
    **/
   //##end setMaster%4D5260780193p.doc

   public void setMaster( Mastered a_Master )
            throws WTPropertyVetoException, WTException {
      //##begin setMaster%4D5260780193p.body preserve=no

      setMasterReference( a_Master == null ? null : ObjectReference.newObjectReference( a_Master ) );
      //##end setMaster%4D5260780193p.body
   }

   //##begin getRoseType%4D52620C0173g.doc preserve=no
   /**
    * Gets the object for the association that plays role: ROSE_TYPE.
    *
    * @return    RoseType
    **/
   //##end getRoseType%4D52620C0173g.doc

   public RoseType getRoseType() {
      //##begin getRoseType%4D52620C0173g.body preserve=no

      return roseType;
      //##end getRoseType%4D52620C0173g.body
   }

   //##begin setRoseType%4D52620C0173s.doc preserve=no
   /**
    * Sets the object for the association that plays role: ROSE_TYPE.
    *
    * @param     a_RoseType
    **/
   //##end setRoseType%4D52620C0173s.doc

   public void setRoseType( RoseType a_RoseType ) {
      //##begin setRoseType%4D52620C0173s.body preserve=no

      roseType = a_RoseType;
      //##end setRoseType%4D52620C0173s.body
   }

   //##begin newRosePart%4D526E960215f.doc preserve=no
   /**
    * @param     name
    * @param     number
    * @return    RosePart
    * @exception wt.util.WTException
    **/
   //##end newRosePart%4D526E960215f.doc

   public static RosePart newRosePart( String name, String number )
            throws WTException {
      //##begin newRosePart%4D526E960215f.body preserve=no

      RosePart instance = new RosePart();
      instance.initialize( name, number );
      return instance;
      //##end newRosePart%4D526E960215f.body
   }

   //##begin initialize%4D526E960215.doc preserve=no
   /**
    * Supports initialization, following construction of an instance.  Invoked
    * by "new" factory having the same signature.
    *
    * @param     name
    * @param     number
    * @exception wt.util.WTException
    **/
   //##end initialize%4D526E960215.doc

   protected void initialize( String name, String number )
            throws WTException {
      //##begin initialize%4D526E960215.body preserve=yes
	  
	  super.initialize(name, number);

      //##end initialize%4D526E960215.body
   }

   //##begin newRosePart%4D52A3E3003Ef.doc preserve=no
   /**
    * @return    RosePart
    * @exception wt.util.WTException
    **/
   //##end newRosePart%4D52A3E3003Ef.doc

   public static RosePart newRosePart()
            throws WTException {
      //##begin newRosePart%4D52A3E3003Ef.body preserve=no

      RosePart instance = new RosePart();
      instance.initialize();
      return instance;
      //##end newRosePart%4D52A3E3003Ef.body
   }

   //##begin newRosePart%4D52A42100F0f.doc preserve=no
   /**
    * @param     number
    * @param     name
    * @param     defaultUnit
    * @return    RosePart
    * @exception wt.util.WTException
    **/
   //##end newRosePart%4D52A42100F0f.doc

   public static RosePart newRosePart( String number, String name, QuantityUnit defaultUnit )
            throws WTException {
      //##begin newRosePart%4D52A42100F0f.body preserve=no

      RosePart instance = new RosePart();
      instance.initialize( number, name, defaultUnit );
      return instance;
      //##end newRosePart%4D52A42100F0f.body
   }

   //##begin initialize%4D52A42100F0.doc preserve=no
   /**
    * Supports initialization, following construction of an instance.  Invoked
    * by "new" factory having the same signature.
    *
    * @param     number
    * @param     name
    * @param     defaultUnit
    * @exception wt.util.WTException
    **/
   //##end initialize%4D52A42100F0.doc

   protected void initialize( String number, String name, QuantityUnit defaultUnit )
            throws WTException {
      //##begin initialize%4D52A42100F0.body preserve=yes
		super.initialize( number, name, defaultUnit );
      //##end initialize%4D52A42100F0.body
   }

   //##begin equals%equals.doc preserve=no
   /**
    * Indicates whether the given object is equal to this object from a
    * persistence perspective, by comparing the two objects <code>ObjectIdentifier</code>s.
    * Changed or stale copies are still considered equal by this method.
    * Delegates to {@link wt.fc.PersistenceHelper#equals(Persistable,Object)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>equals</code> being <code>ObjectIdentifier</code>-based. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     obj
    * @return    boolean
    **/
   //##end equals%equals.doc

   public boolean equals( Object obj ) {
      //##begin equals%equals.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.equals(this,obj);
      //##end equals%equals.body
   }

   //##begin hashCode%hashCode.doc preserve=no
   /**
    * Returns a hash code for this object based upon its <code>ObjectIdentifier</code>.
    * Delegates to {@link wt.fc.PersistenceHelper#hashCode(Persistable)}.
    * <p>
    * <b>Warning:</b> Certain core Windchill operations may depend upon
    * <code>hashCode</code> being <code>ObjectIdentifier-based</code>. Changes
    * to the default implementation should be done with care, if at all.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @return    int
    **/
   //##end hashCode%hashCode.doc

   public int hashCode() {
      //##begin hashCode%hashCode.body preserve=no

      // WARNING: Do not change
      return wt.fc.PersistenceHelper.hashCode(this);
      //##end hashCode%hashCode.body
   }

   //##begin user.operations preserve=yes
   //##end user.operations
}
