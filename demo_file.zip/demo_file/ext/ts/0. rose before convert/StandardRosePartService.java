// Generated StandardRosePartService%4D526436016A: Wed 02/09/11 15:42:41
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.ts.rose;

import ext.ts.rose.RosePart;
import ext.ts.rose.RosePartService;
import ext.ts.rose.RoseType;
import java.io.Serializable;
import java.lang.String;
import wt.services.StandardManager;
import wt.util.WTException;

//##begin user.imports preserve=yes
import wt.fc.PersistenceHelper;
import wt.folder.FolderHelper;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
//##end user.imports

//##begin StandardRosePartService%4D526436016A.doc preserve=no
/**
 *
 * <p>
 * Use the <code>newStandardRosePartService</code> static factory method(s),
 * not the <code>StandardRosePartService</code> constructor, to construct
 * instances of this class.  Instances must be constructed using the static
 * factory(s), in order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
//##end StandardRosePartService%4D526436016A.doc

public class StandardRosePartService extends StandardManager implements RosePartService, Serializable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.ts.rose.roseResource";
   private static final String CLASSNAME = StandardRosePartService.class.getName();

   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=yes
   //##end static.initialization


   // --- Operation Section ---

   //##begin getConceptualClassname%getConceptualClassnameg.doc preserve=no
   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   //##end getConceptualClassname%getConceptualClassnameg.doc

   public String getConceptualClassname() {
      //##begin getConceptualClassname%getConceptualClassnameg.body preserve=no

      return CLASSNAME;
      //##end getConceptualClassname%getConceptualClassnameg.body
   }

   //##begin newStandardRosePartService%newStandardRosePartServicef.doc preserve=no
   /**
    * Default factory for the class.
    *
    * @return    StandardRosePartService
    * @exception wt.util.WTException
    **/
   //##end newStandardRosePartService%newStandardRosePartServicef.doc

   public static StandardRosePartService newStandardRosePartService()
            throws WTException {
      //##begin newStandardRosePartService%newStandardRosePartServicef.body preserve=no

      StandardRosePartService instance = new StandardRosePartService();
      instance.initialize();
      return instance;
      //##end newStandardRosePartService%newStandardRosePartServicef.body
   }

   //##begin createRosePartInSite%4D5266A30319.doc preserve=no
   /**
    * @param     name
    * @param     type
    * @return    RosePart
    * @exception wt.util.WTException
    **/
   //##end createRosePartInSite%4D5266A30319.doc

   public RosePart createRosePartInSite( String name, RoseType type )
            throws WTException {
      //##begin createRosePartInSite%4D5266A30319.body preserve=yes
        WTContainer site = WTContainerHelper.service.getExchangeContainer();
        RosePart part;
        part = RosePart.newRosePart(name, name);
        part.setRoseType(RoseType.toRoseType("rt1"));
        FolderHelper.assignLocation(part, "/Default", WTContainerRef.newWTContainerRef(site));
        return (RosePart) PersistenceHelper.manager.save(part);
      //##end createRosePartInSite%4D5266A30319.body
   }

   //##begin user.operations preserve=yes
   //##end user.operations
}
