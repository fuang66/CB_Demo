// Generated RoseType%4D52618D0285: Wed 02/09/11 11:25:58
/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.ts.rose;

import java.io.Serializable;
import java.lang.IllegalAccessException;
import java.lang.String;
import java.lang.Throwable;
import java.util.Hashtable;
import java.util.Locale;
import wt.fc.EnumeratedType;
import wt.util.WTInvalidParameterException;

//##begin user.imports preserve=yes
//##end user.imports

//##begin RoseType%4D52618D0285.doc preserve=no
/**
 *
 * @version   1.0
 **/
//##end RoseType%4D52618D0285.doc

public final class RoseType extends EnumeratedType implements Serializable {


   // --- Attribute Section ---


   private static final String RESOURCE = "ext.ts.rose.roseResource";
   private static final String CLASSNAME = RoseType.class.getName();
   private static final String CLASS_RESOURCE = "ext.ts.rose.RoseTypeRB";
   private static final EnumeratedType[] valueSet;
   private static Hashtable localeSets;

   //##begin user.attributes preserve=yes
   //##end user.attributes

   //##begin static.initialization preserve=no

   static {
      try { valueSet = initializeLocaleSet( null ); }
      catch ( Throwable t ) { throw new ExceptionInInitializerError( t ); }
   }
   //##end static.initialization


   //##begin RT1%4D5262D101F8.doc preserve=no
   /**
    **/
   //##end RT1%4D5262D101F8.doc
   public static final RoseType RT1 = toRoseType("rt1");


   // --- Operation Section ---

   //##begin RoseType%RoseType.doc preserve=no
   /**
    * Used by sub-classes that need a default constructor.
    *
    **/
   //##end RoseType%RoseType.doc

   protected RoseType() {
      //##begin RoseType%RoseType.body preserve=yes

      //##end RoseType%RoseType.body
   }

   //##begin newRoseType%newRoseTypef.doc preserve=no
   /**
    * Used by EnumeratedType for constructing instances of RoseType, from
    * a resource bundle.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     secretHandshake
    * @return    RoseType
    * @exception java.lang.IllegalAccessException
    **/
   //##end newRoseType%newRoseTypef.doc

   public static RoseType newRoseType( int secretHandshake )
            throws IllegalAccessException {
      //##begin newRoseType%newRoseTypef.body preserve=no

      validateFriendship( secretHandshake );
      return new RoseType();
      //##end newRoseType%newRoseTypef.body
   }

   //##begin toRoseType%toRoseType.doc preserve=no
   /**
    * Returns the RoseType instance for the internal_value argument.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     internal_value  The internal (persistent) value for a valid instance of RoseType.
    * @return    RoseType
    * @exception wt.util.WTInvalidParameterException
    **/
   //##end toRoseType%toRoseType.doc

   public static RoseType toRoseType( String internal_value )
            throws WTInvalidParameterException {
      //##begin toRoseType%toRoseType.body preserve=no

      return (RoseType)toEnumeratedType( internal_value, valueSet );
      //##end toRoseType%toRoseType.body
   }

   //##begin getRoseTypeDefault%getRoseTypeDefaultg.doc preserve=no
   /**
    * Returns the default value (instance) for the RoseType set.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @return    RoseType
    **/
   //##end getRoseTypeDefault%getRoseTypeDefaultg.doc

   public static RoseType getRoseTypeDefault() {
      //##begin getRoseTypeDefault%getRoseTypeDefaultg.body preserve=no

      return (RoseType)defaultEnumeratedType( valueSet );
      //##end getRoseTypeDefault%getRoseTypeDefaultg.body
   }

   //##begin getRoseTypeSet%getRoseTypeSetg.doc preserve=no
   /**
    * Returns a copy of the set of valid values (instances) for the RoseType
    * class.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @return    RoseType[]
    **/
   //##end getRoseTypeSet%getRoseTypeSetg.doc

   public static RoseType[] getRoseTypeSet() {
      //##begin getRoseTypeSet%getRoseTypeSetg.body preserve=no

      // make a copy of the array, to hand out
      RoseType[] set = new RoseType[ valueSet.length ];
      System.arraycopy( valueSet, 0, set, 0, valueSet.length );

      return set;
      //##end getRoseTypeSet%getRoseTypeSetg.body
   }

   //##begin getValueSet%getValueSetg.doc preserve=no
   /**
    * Returns a copy of the set of valid values (instances) for this instance,
    * for the current user locale.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @return    EnumeratedType[]
    **/
   //##end getValueSet%getValueSetg.doc

   public EnumeratedType[] getValueSet() {
      //##begin getValueSet%getValueSetg.body preserve=no

      return getRoseTypeSet();
      //##end getValueSet%getValueSetg.body
   }

   //##begin valueSet%valueSet.doc preserve=no
   /**
    * Returns a reference to the set of valid values (instances) for this
    * instance.
    *
    * @return    EnumeratedType[]
    **/
   //##end valueSet%valueSet.doc

   protected EnumeratedType[] valueSet() {
      //##begin valueSet%valueSet.body preserve=no

      return valueSet;
      //##end valueSet%valueSet.body
   }

   //##begin getLocaleSet%getLocaleSetg.doc preserve=no
   /**
    * Returns the set of values (instances) for this instance, for the specified
    * locale.
    *
    * @param     locale
    * @return    EnumeratedType[]
    **/
   //##end getLocaleSet%getLocaleSetg.doc

   protected EnumeratedType[] getLocaleSet( Locale locale ) {
      //##begin getLocaleSet%getLocaleSetg.body preserve=no

      EnumeratedType[] request = null;

      if ( localeSets == null )
         localeSets = new Hashtable();
      else
      request = (EnumeratedType[])localeSets.get( locale );

      if ( request == null ) {
         try { request = initializeLocaleSet( locale ); }
         catch (Throwable t) { /* snuff, since generation of class ensures that exception will not be thrown */ }
         localeSets.put( locale, request );
      }

      return request;
      //##end getLocaleSet%getLocaleSetg.body
   }

   //##begin initializeLocaleSet%initializeLocaleSet.doc preserve=no
   /**
    * @param     locale
    * @return    EnumeratedType[]
    * @exception java.lang.Throwable
    **/
   //##end initializeLocaleSet%initializeLocaleSet.doc

   private static EnumeratedType[] initializeLocaleSet( Locale locale )
            throws Throwable {
      //##begin initializeLocaleSet%initializeLocaleSet.body preserve=no

      Class[] argType = { Integer.TYPE };
      return instantiateSet( RoseType.class.getMethod( "newRoseType", argType ),
            CLASS_RESOURCE, locale );

      //##end initializeLocaleSet%initializeLocaleSet.body
   }

   //##begin user.operations preserve=yes
   //##end user.operations
}
